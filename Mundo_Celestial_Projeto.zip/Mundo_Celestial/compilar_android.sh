#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
GODOT_BIN="${GODOT_BIN:-godot}"
if ! command -v "$GODOT_BIN" >/dev/null 2>&1; then
  echo "ERRO: Godot nao encontrado. Instale Godot 4.3+ ou defina GODOT_BIN." >&2
  exit 1
fi
mkdir -p build
"$GODOT_BIN" --headless --path . --export-debug "Android" build/MundoCelestial.apk
echo "APK criado em: $(pwd)/build/MundoCelestial.apk"
