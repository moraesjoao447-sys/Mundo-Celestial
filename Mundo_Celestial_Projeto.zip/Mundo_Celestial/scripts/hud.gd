extends Control

var world
var player
var hp_label: Label
var quest_label: Label
var level_label: Label
var joystick_origin := Vector2.ZERO
var joystick_id := -1
var joystick_radius := 72.0
var joy_visual: Control

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _make_panel()
    _make_controls()

func _make_panel() -> void:
    var panel = PanelContainer.new()
    panel.position = Vector2(18,18)
    panel.custom_minimum_size = Vector2(300,112)
    add_child(panel)
    var vb = VBoxContainer.new()
    panel.add_child(vb)
    var title = Label.new()
    title.text = "MUNDO CELESTIAL"
    title.add_theme_font_size_override("font_size",22)
    title.add_theme_color_override("font_color",Color(0.95,0.78,0.36))
    vb.add_child(title)
    hp_label = Label.new()
    vb.add_child(hp_label)
    level_label = Label.new()
    vb.add_child(level_label)
    quest_label = Label.new()
    vb.add_child(quest_label)
    var hint = Label.new()
    hint.text = "Derrote os Lobos Sombrios e evolua."
    hint.add_theme_font_size_override("font_size",13)
    vb.add_child(hint)

func _make_controls() -> void:
    var attack_btn = _button("ATACAR", Vector2(-190,-120), Vector2(150,76))
    attack_btn.pressed.connect(func(): player.attack())
    var skill_btn = _button("HABILIDADE", Vector2(-190,-210), Vector2(150,68))
    skill_btn.pressed.connect(func(): player.use_skill())
    var save_btn = _button("SALVAR", Vector2(22,-74), Vector2(110,48))
    save_btn.pressed.connect(func(): world._save_game())
    # Direcional virtual analógico
    joy_visual = Control.new()
    joy_visual.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    joy_visual.position = Vector2(36,-205)
    joy_visual.custom_minimum_size = Vector2(150,150)
    add_child(joy_visual)
    var circle = ColorRect.new()
    circle.color = Color(0.08,0.12,0.18,0.48)
    circle.size = Vector2(140,140)
    circle.position = Vector2(5,5)
    circle.mouse_filter = Control.MOUSE_FILTER_IGNORE
    joy_visual.add_child(circle)
    var label = Label.new()
    label.text = "◉"
    label.add_theme_font_size_override("font_size",64)
    label.position = Vector2(43,26)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    joy_visual.add_child(label)

func _button(text_value: String, offset: Vector2, size_value: Vector2) -> Button:
    var b = Button.new()
    b.text = text_value
    b.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    b.position = offset
    b.size = size_value
    b.add_theme_font_size_override("font_size",18)
    add_child(b)
    return b

func update_status(hp: int, max_hp: int, level: int, xp: int, kills: int) -> void:
    if hp_label:
        hp_label.text = "Vida: %d / %d" % [hp,max_hp]
        level_label.text = "Nível %d  •  EXP %d/%d" % [level,xp,level*100]
        quest_label.text = "Missão: Lobos derrotados %d/7" % mini(kills,7)

func _input(event: InputEvent) -> void:
    if not player or not joy_visual:
        return
    if event is InputEventScreenTouch:
        var rect = Rect2(Vector2(0,size.y-230),Vector2(220,230))
        if event.pressed and rect.has_point(event.position):
            joystick_id = event.index
            _set_joy(event.position)
        elif not event.pressed and event.index == joystick_id:
            joystick_id = -1
            player.move_touch = Vector2.ZERO
    elif event is InputEventScreenDrag and event.index == joystick_id:
        _set_joy(event.position)

func _set_joy(pos: Vector2) -> void:
    var center = Vector2(111,size.y-130)
    var delta = pos - center
    if delta.length() > joystick_radius:
        delta = delta.normalized() * joystick_radius
    player.move_touch = Vector2(delta.x,delta.y) / joystick_radius
