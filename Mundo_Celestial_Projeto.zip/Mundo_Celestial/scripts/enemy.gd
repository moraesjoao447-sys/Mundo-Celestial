extends CharacterBody3D

var hp := 65
var max_hp := 65
var speed := 2.3
var attack_timer := 0.0
var target
var home: Vector3

func _ready() -> void:
    target = get_parent().get_node_or_null("Heroi")
    home = global_position
    var mesh = MeshInstance3D.new()
    var sm = SphereMesh.new()
    sm.radius = 0.72
    sm.height = 1.35
    mesh.mesh = sm
    mesh.position.y = 0.72
    var fur = StandardMaterial3D.new()
    fur.albedo_color = Color(0.22,0.10,0.16)
    fur.roughness = 0.9
    mesh.material_override = fur
    add_child(mesh)
    var eyes = MeshInstance3D.new()
    var em = BoxMesh.new()
    em.size = Vector3(0.38,0.10,0.12)
    eyes.mesh = em
    eyes.position = Vector3(0,1.05,-0.61)
    var red = StandardMaterial3D.new()
    red.albedo_color = Color(1.0,0.12,0.08)
    red.emission_enabled = true
    red.emission = Color(0.8,0.04,0.02)
    eyes.material_override = red
    add_child(eyes)
    var col = CollisionShape3D.new()
    var shape = SphereShape3D.new()
    shape.radius = 0.7
    col.shape = shape
    col.position.y = 0.7
    add_child(col)

func _physics_process(delta: float) -> void:
    if not is_instance_valid(target):
        return
    attack_timer = maxf(0.0, attack_timer - delta)
    var dist = global_position.distance_to(target.global_position)
    if dist < 13.0 and dist > 1.7:
        var d = (target.global_position - global_position).normalized()
        velocity.x = d.x * speed
        velocity.z = d.z * speed
        look_at(Vector3(target.global_position.x, global_position.y, target.global_position.z))
    elif dist <= 1.7:
        velocity.x = 0
        velocity.z = 0
        if attack_timer <= 0:
            attack_timer = 1.5
            target.take_damage(7)
    else:
        velocity.x = move_toward(velocity.x,0,8*delta)
        velocity.z = move_toward(velocity.z,0,8*delta)
    if not is_on_floor():
        velocity.y -= 24.0 * delta
    else:
        velocity.y = -0.5
    move_and_slide()

func take_damage(amount: int, attacker) -> void:
    hp -= amount
    if hp <= 0:
        attacker.gain_xp(25)
        get_parent().enemy_defeated(self)
