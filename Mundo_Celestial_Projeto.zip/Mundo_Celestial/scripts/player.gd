extends CharacterBody3D

var speed := 7.0
var hp := 100
var max_hp := 100
var level := 1
var xp := 0
var attack_cooldown := 0.0
var skill_cooldown := 0.0
var world
var camera_pivot: Node3D
var visual: Node3D
var move_touch := Vector2.ZERO

func _ready() -> void:
    world = get_parent()
    _build_character()
    _build_camera()
    var col = CollisionShape3D.new()
    var capsule = CapsuleShape3D.new()
    capsule.radius = 0.48
    capsule.height = 1.9
    col.shape = capsule
    add_child(col)
    position.y = max(position.y, 1.0)

func _build_character() -> void:
    visual = Node3D.new()
    add_child(visual)
    var body = MeshInstance3D.new()
    var capsule = CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.9
    body.mesh = capsule
    body.position.y = 0.95
    var armor = StandardMaterial3D.new()
    armor.albedo_color = Color(0.18,0.32,0.68)
    armor.metallic = 0.35
    body.material_override = armor
    visual.add_child(body)
    var head = MeshInstance3D.new()
    var sphere = SphereMesh.new()
    sphere.radius = 0.34
    sphere.height = 0.68
    head.mesh = sphere
    head.position.y = 2.05
    var skin = StandardMaterial3D.new()
    skin.albedo_color = Color(0.82,0.65,0.49)
    head.material_override = skin
    visual.add_child(head)
    var blade = MeshInstance3D.new()
    var bm = BoxMesh.new()
    bm.size = Vector3(0.12,1.25,0.18)
    blade.mesh = bm
    blade.position = Vector3(0.58,1.0,-0.15)
    blade.rotation.z = -0.28
    var steel = StandardMaterial3D.new()
    steel.albedo_color = Color(0.72,0.82,0.9)
    steel.metallic = 0.8
    blade.material_override = steel
    visual.add_child(blade)

func _build_camera() -> void:
    camera_pivot = Node3D.new()
    camera_pivot.position = Vector3(0,2.2,0)
    add_child(camera_pivot)
    var cam = Camera3D.new()
    cam.position = Vector3(0,3.2,8.5)
    cam.rotation_degrees.x = -18
    cam.current = true
    cam.fov = 72
    camera_pivot.add_child(cam)

func _physics_process(delta: float) -> void:
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    skill_cooldown = maxf(0.0, skill_cooldown - delta)
    var input_vec = Input.get_vector("move_left","move_right","move_forward","move_back")
    if move_touch.length() > 0.12:
        input_vec = move_touch
    var direction = (transform.basis * Vector3(input_vec.x,0,input_vec.y)).normalized()
    if direction.length() > 0.05:
        velocity.x = direction.x * speed
        velocity.z = direction.z * speed
        visual.rotation.y = lerp_angle(visual.rotation.y, atan2(-direction.x,-direction.z), delta*10.0)
    else:
        velocity.x = move_toward(velocity.x,0,24*delta)
        velocity.z = move_toward(velocity.z,0,24*delta)
    if not is_on_floor():
        velocity.y -= 24.0 * delta
    else:
        velocity.y = -0.5
    move_and_slide()
    if Input.is_action_just_pressed("attack"):
        attack()
    if Input.is_action_just_pressed("skill"):
        use_skill()

func attack() -> void:
    if attack_cooldown > 0:
        return
    attack_cooldown = 0.55
    _hit_nearby(3.0, 24 + level * 4)

func use_skill() -> void:
    if skill_cooldown > 0:
        return
    skill_cooldown = 4.0
    _hit_nearby(5.5, 55 + level * 8)

func _hit_nearby(radius: float, damage: int) -> void:
    for enemy in world.enemies.duplicate():
        if is_instance_valid(enemy) and global_position.distance_to(enemy.global_position) <= radius:
            enemy.take_damage(damage, self)

func gain_xp(amount: int) -> void:
    xp += amount
    while xp >= level * 100:
        xp -= level * 100
        level += 1
        max_hp += 15
        hp = max_hp

func take_damage(amount: int) -> void:
    hp = maxi(0, hp - amount)
    if hp <= 0:
        hp = max_hp
        global_position = Vector3(0,2,5)
