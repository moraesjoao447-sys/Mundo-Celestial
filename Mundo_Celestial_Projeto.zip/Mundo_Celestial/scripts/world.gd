extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
const EnemyScript = preload("res://scripts/enemy.gd")

var player
var hud
var enemies: Array = []
var quest_progress := 0
var saved_path := "user://mundo_celestial_save.json"
var world_time := 0.0

func _ready() -> void:
    _make_environment()
    _make_terrain()
    _make_landmarks()
    player = CharacterBody3D.new()
    player.set_script(PlayerScript)
    player.name = "Heroi"
    add_child(player)
    player.position = Vector3(0, 2, 5)
    _spawn_enemies()
    _make_hud()
    _load_game()

func _process(delta: float) -> void:
    world_time += delta
    var sun = get_node_or_null("DirectionalLight3D")
    if sun:
        sun.rotation.x = -0.75 + sin(world_time * 0.025) * 0.12
    if hud and is_instance_valid(player):
        hud.update_status(player.hp, player.max_hp, player.level, player.xp, quest_progress)

func _make_environment() -> void:
    var env_node = WorldEnvironment.new()
    var env = Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    var sky_mat = ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.08, 0.19, 0.36)
    sky_mat.sky_horizon_color = Color(0.68, 0.76, 0.83)
    sky_mat.ground_bottom_color = Color(0.08, 0.10, 0.12)
    sky_mat.ground_horizon_color = Color(0.38, 0.48, 0.48)
    env.sky.sky_material = sky_mat
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.55, 0.64, 0.78)
    env.ambient_light_energy = 0.7
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env_node.environment = env
    add_child(env_node)
    var sun = DirectionalLight3D.new()
    sun.name = "DirectionalLight3D"
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    add_child(sun)

func _make_terrain() -> void:
    var body = StaticBody3D.new()
    body.name = "Terreno"
    add_child(body)
    var mesh = PlaneMesh.new()
    mesh.size = Vector2(180, 180)
    mesh.subdivide_width = 48
    mesh.subdivide_depth = 48
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.16, 0.34, 0.22)
    mat.roughness = 1.0
    mesh.material = mat
    var ground = MeshInstance3D.new()
    ground.mesh = mesh
    body.add_child(ground)
    var shape = CollisionShape3D.new()
    var box = BoxShape3D.new()
    box.size = Vector3(180, 1, 180)
    shape.shape = box
    shape.position.y = -0.55
    body.add_child(shape)
    # Caminho de pedra central
    _box_prop("Caminho", Vector3(0, -0.02, -13), Vector3(7, 0.15, 62), Color(0.38,0.36,0.32))
    # Colinas decorativas
    for i in range(18):
        var x = float((i * 37) % 150) - 75.0
        var z = float((i * 53) % 150) - 75.0
        if abs(x) < 13 and abs(z) < 20:
            continue
        _rock(Vector3(x, 0, z), 2.5 + float(i % 4) * 1.2)

func _make_landmarks() -> void:
    # Portal ancestral
    _box_prop("Portal_Base", Vector3(0, 0.25, -22), Vector3(9, 0.5, 2), Color(0.42,0.34,0.22))
    for x in [-3.5, 3.5]:
        _box_prop("Portal_Pilar", Vector3(x, 3.2, -22), Vector3(0.8, 6, 0.8), Color(0.68,0.54,0.30))
    _box_prop("Portal_Topo", Vector3(0, 6.1, -22), Vector3(8, 0.8, 0.8), Color(0.72,0.59,0.32))
    # Cristal central
    var crystal = MeshInstance3D.new()
    var cm = PrismMesh.new()
    cm.size = Vector3(2.0, 4.0, 2.0)
    crystal.mesh = cm
    var cmat = StandardMaterial3D.new()
    cmat.albedo_color = Color(0.20,0.75,0.95)
    cmat.emission_enabled = true
    cmat.emission = Color(0.08,0.42,0.8)
    cmat.emission_energy_multiplier = 1.8
    crystal.material_override = cmat
    crystal.position = Vector3(0,2,-22)
    add_child(crystal)
    # Árvores estilizadas
    for i in range(34):
        var x = float((i * 29) % 110) - 55.0
        var z = float((i * 41) % 110) - 55.0
        if abs(x) < 9 and z < 5 and z > -38:
            continue
        _tree(Vector3(x,0,z), 0.8 + float(i%5)*0.12)

func _tree(pos: Vector3, scale_factor: float) -> void:
    var trunk = MeshInstance3D.new()
    var tm = CylinderMesh.new()
    tm.top_radius = 0.18
    tm.bottom_radius = 0.32
    tm.height = 2.2
    trunk.mesh = tm
    trunk.position = pos + Vector3(0,1.1,0)
    trunk.scale = Vector3.ONE * scale_factor
    var bark = StandardMaterial3D.new()
    bark.albedo_color = Color(0.27,0.16,0.10)
    trunk.material_override = bark
    add_child(trunk)
    var crown = MeshInstance3D.new()
    var sm = SphereMesh.new()
    sm.radius = 1.55
    sm.height = 3.0
    crown.mesh = sm
    crown.position = pos + Vector3(0,3.0,0)
    crown.scale = Vector3(1.0,1.25,1.0) * scale_factor
    var leaves = StandardMaterial3D.new()
    leaves.albedo_color = Color(0.12,0.34,0.19)
    crown.material_override = leaves
    add_child(crown)

func _rock(pos: Vector3, s: float) -> void:
    var rock = MeshInstance3D.new()
    var m = SphereMesh.new()
    m.radius = 1.0
    rock.mesh = m
    rock.position = pos + Vector3(0,s*0.35,0)
    rock.scale = Vector3(s, s*0.65, s*0.8)
    var material = StandardMaterial3D.new()
    material.albedo_color = Color(0.28,0.32,0.34)
    rock.material_override = material
    add_child(rock)

func _box_prop(n: String, pos: Vector3, size: Vector3, color: Color) -> void:
    var mi = MeshInstance3D.new()
    mi.name = n
    var bm = BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.position = pos
    var mat = StandardMaterial3D.new()
    mat.albedo_color = color
    mi.material_override = mat
    add_child(mi)

func _spawn_enemies() -> void:
    for i in range(7):
        var e = CharacterBody3D.new()
        e.set_script(EnemyScript)
        e.name = "LoboSombrio_%d" % i
        add_child(e)
        e.position = Vector3(-17 + (i%4)*11, 1, -8 - int(i/4)*15)
        enemies.append(e)

func enemy_defeated(enemy) -> void:
    quest_progress += 1
    if is_instance_valid(enemy):
        enemy.queue_free()
    if quest_progress % 3 == 0:
        player.gain_xp(40)
    _save_game()

func _make_hud() -> void:
    var layer = CanvasLayer.new()
    add_child(layer)
    var script = load("res://scripts/hud.gd")
    hud = Control.new()
    hud.set_script(script)
    layer.add_child(hud)
    hud.world = self
    hud.player = player

func _save_game() -> void:
    var data = {"level": player.level, "xp": player.xp, "hp": player.hp, "kills": quest_progress, "pos": [player.global_position.x, player.global_position.y, player.global_position.z]}
    var f = FileAccess.open(saved_path, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(data))
        f.close()

func _load_game() -> void:
    if not FileAccess.file_exists(saved_path):
        return
    var f = FileAccess.open(saved_path, FileAccess.READ)
    if not f:
        return
    var parsed = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(parsed) == TYPE_DICTIONARY:
        player.level = int(parsed.get("level",1))
        player.xp = int(parsed.get("xp",0))
        player.hp = int(parsed.get("hp",100))
        quest_progress = int(parsed.get("kills",0))
        var p = parsed.get("pos", [0,2,5])
        if p.size() == 3:
            player.position = Vector3(float(p[0]),float(p[1]),float(p[2]))
