# Mundo Celestial — projeto-fonte para compilação Android

Projeto 3D offline feito em **Godot 4.3 ou superior**, com renderizador Compatibility para ampliar a compatibilidade com celulares Android.

## O que está incluído

- Projeto Godot com cena inicial e scripts organizados.
- Mundo 3D procedural, iluminação, céu, terreno, caminho, árvores, rochas e portal.
- Personagem em terceira pessoa, câmera e movimentação por teclado ou joystick de toque.
- Ataque corpo a corpo e habilidade em área.
- Lobos inimigos com perseguição e ataque.
- Vida, experiência, níveis, missão de caça e salvamento local.
- HUD com controles de toque.
- Preset de exportação Android (`export_presets.cfg`) configurado para `arm64-v8a`.
- Scripts para exportar o APK no Windows e Linux.

> **Importante:** este pacote contém os arquivos-fonte e a configuração de exportação. O APK ainda precisa ser gerado em um computador com Godot, templates de exportação e Android SDK/JDK configurados. Não foi possível validar uma compilação real neste ambiente porque o editor/compilador Godot e o SDK Android não estão instalados aqui.

## Requisitos para compilar

1. Godot 4.3 ou superior (recomendado usar a versão estável mais recente da série 4.x).
2. Templates de exportação do Godot exatamente correspondentes à versão instalada.
3. Android Studio com Android SDK, Platform Tools e Build Tools instalados.
4. JDK 17.
5. No Godot, em **Editor > Editor Settings > Export > Android**, configurar os caminhos do Android SDK e do JDK.

## Compilar pelo editor Godot

1. Extraia a pasta `Mundo_Celestial`.
2. Abra `project.godot` no Godot.
3. Aguarde a importação dos recursos.
4. Pressione F6/F5 para testar no computador.
5. Abra **Project > Export** e confira o preset **Android**.
6. Para testes, use **Export Project** com a opção de depuração habilitada e salve como `build/MundoCelestial.apk`.

## Compilar por script

- Windows: execute `COMPILAR_ANDROID.bat`.
- Linux: execute `./compilar_android.sh`.
- Alternativa por terminal: `godot --headless --path . --export-debug "Android" build/MundoCelestial.apk`.

O comando precisa ser executado na pasta do projeto. O Godot deve ter os templates de exportação instalados e o ambiente Android configurado.

## Instalar no celular

Ative as opções de desenvolvedor e a depuração USB, conecte o aparelho e execute:

```bash
adb install -r build/MundoCelestial.apk
```

Também é possível copiar o APK para o aparelho e abri-lo, autorizando a instalação de fontes externas quando o Android solicitar.

## Identificação do aplicativo

- Nome: Mundo Celestial
- Pacote: `com.mundocelestial.rpg`
- Versão: `1.0.0`
- Arquitetura incluída no preset: `arm64-v8a`
- Orientação: paisagem
- Renderizador: Compatibility / OpenGL ES

## Controles

- PC: WASD/setas para mover, Espaço para atacar, F para habilidade.
- Android: joystick virtual à esquerda; botões ATACAR e HABILIDADE à direita.

## Estado atual e próximos módulos

Esta é a base inicial jogável/prototípica. O mundo aberto contínuo com oito regiões, criação de personagens, seis classes, voo, montarias, cidades completas, NPCs, inventário avançado, crafting e dungeons está planejado, mas **não está todo implementado nesta versão**. Os recursos gráficos são gerados proceduralmente e são originais; não são arquivos extraídos de Perfect World.

Antes de publicar na Play Store, será necessário configurar uma chave de assinatura de release, testar em aparelhos reais, definir política de privacidade e revisar os requisitos atuais da loja.

## Compilação online pelo GitHub Actions

1. Crie uma conta no GitHub e um repositório vazio.
2. Envie todos os arquivos desta pasta para o repositório (incluindo a pasta `.github/workflows`).
3. Abra a aba **Actions** do repositório.
4. Selecione **Compilar Mundo Celestial para Android** e clique em **Run workflow**. Um push nas branches `main` ou `master` também inicia a compilação.
5. Quando o processo terminar, abra a execução concluída e baixe o artefato **Mundo-Celestial-APK**.

O workflow gera um APK de depuração para testes. Para distribuição pública/Play Store, configure uma chave de assinatura de lançamento (keystore) como segredo do GitHub e faça uma exportação Release. Não publique credenciais de assinatura no repositório.
