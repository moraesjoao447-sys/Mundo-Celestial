@echo off
setlocal
cd /d "%~dp0"
where godot >nul 2>nul
if errorlevel 1 (
  echo ERRO: Godot nao foi encontrado no PATH.
  echo Instale Godot 4.3 ou superior e adicione godot.exe ao PATH.
  pause
  exit /b 1
)
if not exist build mkdir build
echo Exportando Mundo Celestial para Android...
godot --headless --path "%~dp0" --export-debug "Android" "%~dp0build\MundoCelestial.apk"
if errorlevel 1 (
  echo.
  echo A exportacao falhou. Confira os templates de exportacao e o Android SDK/JDK nas configuracoes do Godot.
  pause
  exit /b 1
)
echo APK criado em: %~dp0build\MundoCelestial.apk
pause
